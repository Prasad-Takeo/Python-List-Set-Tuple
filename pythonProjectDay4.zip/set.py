#set - datatype
#an unordered collection of data type that is mutable
#no duplicate element
#set are not subscriptable - indexed based access is not allowed

#declaration
set1 = set((1,3))
print(set1)

set2 = {1,2}
print(set2)

set4 = {1,2,3,3,4,5,6,5,4}
print(set4)

set5 = {"apple","mango","mango","banana"}

#adding and updating a set
set4.add((7,8)) #{"apple",("2","3","7","8","9")}
print(set4)

set4.remove(5) #raise the error if the element does not exist
print(set4)

set4.discard(4)
print(set4)

set4.discard(4)
# set4.remove(5)

print(set5)

set5.remove("mango")
print(set5)

set5.pop()
print(set5)

set5.clear()
print(set5)

set6 = {1,2,4,5,6,8,(8,9,10)}
#hashable - set can only contains hashable objects,and a set is not hashable
#invalid - {1,2,4,5,6,8,{9,10}}
#invalid - {1,2,4,5,6,8,[9,10]}

print(set6)
#accessing the element
for j in set6: #cannot access the element by referring to an index
    print(type(j),j)

#set is mutable but set cannot contain changeable objects (or)
# can contain only un-changeable objects
s = set()
s.add((1,2))
print(s)
s.add("a")
print(s)
s.add(8)
print(s)

#adding multiple items to the set at once

s1= set()
[ s1.add(each) for each in  range(10)]
print(s1)

test_set = {6,4,2,7,9}  #tuple- (), list=[], set={}
l1 = [1,5,10]
test_set.update(l1)
print(test_set)

test_set = {6,4,2,7,9}
l1 = [1,5,10]
test_set |= set(l1)
print(test_set)

test_set = {6,4,2,7,9}  #tuple- (), list=[], set={}
l1 = [1,5,10]
l1.extend(test_set)
print(l1)
print(dir(l1))

#set operations
#union, intersection, difference,
a = {0,2,4,6,8}
b = {1,2,3,4,5}

print(dir(a))
print(a|b)#union
print(a&b)#intersection
print(a-b)#difference - getting non-overlapped elements of first operand
print(a^b)#symmetric difference - get overall non-overlapped elements
#
l1 = [1,2,3]
l2 = [5,6,7]
print(l1+l2)
print(l1.extend(l2))
# print(l2.extend(l1))

tup1 = (1,2,4)
tup2 = (3,7,8,4)
tup3 = set(tup1)&set(tup2)
print(tup3)

