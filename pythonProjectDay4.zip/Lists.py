#Lists - just like array, mulitple data types like integers, strings, float, any objects

L1 = ["1","bootcamp","2.2342"]

#indexing
#forward index startswith 0 and increement by 1 ( left to right )
#reverse index starswith -1 and increement by -1( right to left )

print(L1[0])
print(L1[1])
print(L1[2])

print(L1[-1])
print(L1[-2])
print(L1[-3])

# functions supported by list
# slicing - start, stop, step

print(L1[0:2])
print(L1[-1:-3:-1])
print(L1[::-1])

#append
l2=[] #stack - pile of coins,books - LIFO
print(id(l2))
l2.append('a')
l2.append('b')
l2.append('c')
print(l2) #[a,b,c]
#insert
l2.insert(1,"bb") #-> insert in the 1st index
print(l2) #[a,bb,b,c]
l2.insert(len(l2),"cc")
print(l2) #[a,bb,b,c,cc]
#remove
l2.remove("cc")
print(l2) #[a,bb,b,c]
#pop
print(l2.pop()) ## removes the last element -> c -> [a,bb,b]
print(l2)
print(l2.pop(2)) ## removes the 2nd index element -> b
print(l2)
print(id(l2))
#mutable -> changes can be done in the assigne memory location

#sorting
l1 = [1,8,3,5,2,-1,2.234,79,2341]
print(id(l1))
l1.sort(reverse=True) #in-place sort #return empty
print(l1)
print(id(l1))

sorted_list = sorted(l1,reverse=True) #create a new sorted list and returns the new sorted list
print(sorted_list)
print(id(sorted_list))

#list - string
l1 = ["apple","banana","mango"]
list_to_str = "-".join(l1)
print(list_to_str)

print(tuple(l1))
