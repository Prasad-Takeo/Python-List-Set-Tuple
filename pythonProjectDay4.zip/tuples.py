#tuples is one of the datatype similar to list but the difference is tuple is read-only list
#which means tuple is immutable

#Declaration
t1 = tuple(("a","b","c"))
print(t1)
t1 = (1,2,3)
print(t1)

#accessing elements of tuple
tuple1 = tuple([1,2,3,4,5])
print(tuple1[0])
print(tuple1[-1])

#immutable - can't change the structure once assinged to the memory location
# tuple1[0] = 6

#slicing - start,stop,step
print(tuple1[0:3])

#unpacking the tuple
firstname,lastname,username,password,age = ("sugumar","v","test","***",None)
print(firstname)
print(lastname)
print(username)
print(password)
print(age)

#comparing tuples
a = (5,5)
b = (5,5)
if (b>a): print("a is bigger")
else:print("b is bigger")

#type-casting
print(list(tuple1)) #mutable
a = list(tuple1)
a[2] = 5
print(a)

#boolean- True,False
print(1==True)
print(0==False)
while False:
    print("infinite loop")
